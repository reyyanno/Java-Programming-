import java.util.Scanner;

interface Rentable {
    double calculateRentalCost(int days);
}

abstract class Vehicle implements Rentable {
    String modelName;
    String licensePlate;
    double basePricePerDay;

    public Vehicle(String modelName, String licensePlate, double basePricePerDay) {
        this.modelName = modelName;
        this.licensePlate = licensePlate;
        this.basePricePerDay = basePricePerDay;
    }

    abstract void displayDetails();
}

class Car extends Vehicle {
    public Car(String modelName, String licensePlate, double basePricePerDay) {
        super(modelName, licensePlate, basePricePerDay);
    }

    void displayDetails() {
        System.out.println("car: " + modelName);
    }

    public double calculateRentalCost(int days) {
        double cost = basePricePerDay * days;
        if (days > 7) {
            cost *= 0.9;
        }
        return cost;
    }
}

class Bike extends Vehicle {
    public Bike(String modelName, String licensePlate, double basePricePerDay) {
        super(modelName, licensePlate, basePricePerDay);
    }

    void displayDetails() {
        System.out.println("bike: " + modelName);
    }

    public double calculateRentalCost(int days) {
        double cost = basePricePerDay * days;
        if (days > 5) {
            cost *= 0.95;
        }
        return cost;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Car car = new Car("Mercedes", "AUMR1907", 50);
        Bike bike = new Bike("fleg", "AUF6868", 30);

        System.out.println("choose a car pls : 1. car 2. bike");
        int choice = scanner.nextInt();

        if (choice != 1 && choice != 2) {
            System.out.println("unfortunately invalid choice.");
            return;
        }

        System.out.print("enter number of days pls: ");
        int days = scanner.nextInt();

        if (days <= 0) {
            System.out.println("heeyy days must be positive.");
            return;
        }

        Vehicle vehicle = choice == 1 ? car : bike;
        vehicle.displayDetails();
        double cost = vehicle.calculateRentalCost(days);
        System.out.println("and the total cost: " + cost);
    }
}
